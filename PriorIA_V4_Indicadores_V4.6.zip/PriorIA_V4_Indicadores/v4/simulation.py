"""Multi-day PriorIA runs with a discarded warm-up period."""
from __future__ import annotations

from copy import deepcopy
from collections import defaultdict
from typing import Any

from v2.generate_patients import generate_patients
from v2.simulate_day import simulate_day

MINUTES_PER_DAY = 24 * 60
BASE_PATIENTS_PER_DAY = 100


def simulate_period(config: dict[str, Any], simulation_days: int,
                    warmup_days: int = 1) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    """Run whole warm-up days, then collect metrics during the requested period.

    Patients and resources remain in the same simulation across the warm-up and
    observation boundary. Warm-up arrivals are excluded from patient-level
    metrics, but can remain in queues or active care during the measured period.
    """
    simulation_days = int(simulation_days)
    warmup_days = int(warmup_days)
    if not 1 <= simulation_days <= 7:
        raise ValueError("simulation_days debe estar entre 1 y 7.")
    if not 0 <= warmup_days <= 3:
        raise ValueError("warmup_days debe estar entre 0 y 3.")
    if int(config.get("daily_patients", BASE_PATIENTS_PER_DAY)) != BASE_PATIENTS_PER_DAY:
        raise ValueError("PriorIA V4 usa un volumen de referencia fijo de 100 pacientes/día.")
    attention_nurses = int(config["resources"].get("box_nurses", 3))
    if not 1 <= attention_nurses <= 3:
        raise ValueError("La dotación de enfermería de atención debe estar entre 1 y 3.")

    total_days = warmup_days + simulation_days
    seed = int(config["seed"])
    profiles: list[dict[str, Any]] = []
    for day_index in range(total_days):
        day_config = deepcopy(config)
        day_config["daily_patients"] = BASE_PATIENTS_PER_DAY
        day_config["seed"] = seed + day_index * 104729
        daily = generate_patients(day_config)
        for profile in daily:
            profile["patient_id"] = f"D{day_index + 1:02d}-{profile['patient_id']}"
            profile["arrival_minute"] += day_index * MINUTES_PER_DAY
            profile["arrival_day"] = day_index + 1
            profiles.append(profile)

    observed_start = warmup_days * MINUTES_PER_DAY
    observed_end = total_days * MINUTES_PER_DAY
    run_config = deepcopy(config)
    run_config["daily_patients"] = BASE_PATIENTS_PER_DAY
    run_config["max_simulation_minutes"] = observed_end + 7 * MINUTES_PER_DAY
    summary, trace = simulate_day(
        run_config,
        patient_profiles=profiles,
        observation_window=(observed_start, observed_end),
    )
    summary.update({
        "simulation_days": simulation_days,
        "warmup_days": warmup_days,
        "observation_start_minute": observed_start,
        "observation_end_minute": observed_end,
        "warmup_patients": sum(p["arrival_minute"] < observed_start for p in profiles),
        "generated_total_with_warmup": len(profiles),
        "patients_per_day_reference": BASE_PATIENTS_PER_DAY,
    })
    return summary, trace


def dashboard_data(trace: list[dict[str, Any]], summary: dict[str, Any],
                   config: dict[str, Any]) -> dict[str, Any]:
    """Return cohort indicators and capacity-normalized resource utilization."""
    start = int(summary["observation_start_minute"])
    end = int(summary["observation_end_minute"])
    duration = max(1, end - start)
    patient_rows = [row for row in trace if row.get("event") == "patient_summary"]
    events_by_patient: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for event in trace:
        if event.get("patient_id") and event.get("event") != "patient_summary":
            events_by_patient[str(event["patient_id"])].append(event)

    arrivals_by_hour = [0] * 24
    for event in trace:
        minute = int(event.get("minute", -1))
        if event.get("event") == "arrived" and start <= minute < end:
            arrivals_by_hour[((minute - start) % MINUTES_PER_DAY) // 60] += 1

    category_counts = {f"C{i}": 0 for i in range(1, 6)}
    cohort_count = 0
    for patient in patient_rows:
        if start <= int(patient.get("arrival_minute", -1)) < end:
            cohort_count += 1
            category = patient.get("triage_category")
            if category in category_counts:
                category_counts[category] += 1

    stages: dict[str, list[float]] = {
        "Llegada a categorización completa": [],
        "Llegada a inicio de triage": [],
        "Duración de triage": [],
        "Llegada a PriorIA completa": [],
        "Llegada a triage humano completo": [],
        "Espera atención": [],
        "Espera hospitalización": [], "Espera reevaluación": [],
        "Permanencia total (LOS)": [],
    }
    state_names = {"no_atendido": "No atendido", "categorizado": "Categorizado",
                   "esperando_reevaluacion": "Esperando reevaluación",
                   "atendido": "Atendido"}
    state_counts = {label: 0 for label in state_names.values()}
    for patient in patient_rows:
        patient_id = str(patient["patient_id"])
        if not start <= int(patient.get("arrival_minute", -1)) < end:
            continue
        patient_events = sorted(events_by_patient.get(patient_id, []),
                                key=lambda row: int(row.get("minute", -1)))
        at = lambda name: next((int(row["minute"]) for row in patient_events
                                if row.get("event") == name), None)
        arrival = int(patient["arrival_minute"])
        triage_started = at("triage_started")
        triaged = at("triage_completed")
        consulted = at("called_to_consult")
        if triaged is not None:
            elapsed_to_triage = max(0, triaged - arrival)
            stages["Llegada a categorización completa"].append(elapsed_to_triage)
            if triage_started is not None:
                stages["Llegada a inicio de triage"].append(
                    max(0, triage_started - arrival))
                stages["Duración de triage"].append(
                    max(0, triaged - triage_started))
                triage_event = next((row for row in patient_events
                                     if row.get("event") == "triage_started"), {})
                if triage_event.get("mode") == "prioria":
                    stages["Llegada a PriorIA completa"].append(elapsed_to_triage)
                elif triage_event.get("mode") == "human":
                    stages["Llegada a triage humano completo"].append(elapsed_to_triage)
        if triaged is not None and consulted is not None:
            stages["Espera atención"].append(max(0, consulted - triaged))
        elif patient.get("triage_category") == "C1" and consulted is not None:
            # C1 bypasses routine triage and enters resuscitation directly.
            stages["Espera atención"].append(max(0, consulted - arrival))
        reevaluation_queue: int | None = None
        for event in patient_events:
            kind = event.get("event")
            minute = int(event.get("minute", 0))
            if kind == "treatment_completed_waiting_reevaluation":
                reevaluation_queue = minute
            elif kind == "called_to_reevaluation" and reevaluation_queue is not None:
                stages["Espera reevaluación"].append(
                    max(0, minute - reevaluation_queue))
                reevaluation_queue = None
        if reevaluation_queue is not None:
            # An unfinished episode is right-censored at the last observed event.
            censor_at = max(end, int(patient.get("terminal_minute") or end))
            stages["Espera reevaluación"].append(max(0, censor_at - reevaluation_queue))
        status = patient.get("status")
        terminal = next((int(row["minute"]) for row in reversed(patient_events)
                         if row.get("event") in {"discharged", "hospitalized", "abandoned"}), None)
        last_care = next((int(row["minute"]) for row in reversed(patient_events)
                          if row.get("event") == "care_stage_completed"), None)
        decision = at("hospitalization_decision")
        bed_ready = at("hospitalized")
        if decision is not None:
            wait_end = bed_ready if bed_ready is not None else int(
                patient.get("terminal_minute") or end)
            stages["Espera hospitalización"].append(max(0, wait_end - decision))
        elif status == "unresolved":
            terminal = int(patient.get("terminal_minute") or end)
        if terminal is not None:
            stages["Permanencia total (LOS)"].append(max(0, terminal - arrival))

        operational_state = str(patient.get("operational_state", "no_atendido"))
        state_counts[state_names.get(operational_state, "No atendido")] += 1

    def intervals(start_events: set[str], end_events: set[str],
                  condition=lambda event: True) -> list[tuple[int, int]]:
        active: dict[str, int] = {}
        found: list[tuple[int, int]] = []
        for event in trace:
            kind = event.get("event")
            minute = int(event.get("minute", -1))
            pid = str(event.get("patient_id", ""))
            if not pid:
                continue
            if kind in start_events and condition(event):
                if pid not in active:
                    active[pid] = minute
            elif kind in end_events and pid in active:
                found.append((active.pop(pid), minute))
        found.extend((opened, end) for opened in active.values())
        return [(max(start, a), min(end, b)) for a, b in found
                if min(end, b) > max(start, a)]

    def utilization(spans: list[tuple[int, int]], capacity: int) -> float:
        busy = sum(b - a for a, b in spans)
        return round(100 * busy / (max(1, capacity) * duration), 1) if capacity else 0.0

    resources = config["resources"]
    windowed = lambda spans: [(max(start, a), min(end, b)) for a, b in spans
                              if min(end, b) > max(start, a)]
    def spans_for(start_event: str | set[str], end_event: str | set[str],
                  condition=lambda event: True) -> list[tuple[int, int]]:
        starts = {start_event} if isinstance(start_event, str) else start_event
        ends = {end_event} if isinstance(end_event, str) else end_event
        return windowed(intervals(starts, ends, condition))

    def utilization_rows_for(label: str, spans: list[tuple[int, int]], capacity: int,
                             group: str):
        return {"label": label, "value": utilization(spans, capacity),
                "capacity": capacity, "group": group}

    utilization_rows = []

    chair_minutes = {
        "general": int(summary.get("chair_occupied_minutes_general", 0)),
        "c2": int(summary.get("chair_occupied_minutes_c2", 0)),
    }
    chair_capacity = {
        "general": int(resources.get("general_waiting_chairs", 0)),
        "c2": int(resources.get("c2_waiting_chairs", 0)),
    }
    utilization_rows.extend([
        {"label": "Sillas sala general", "value": round(100 * chair_minutes["general"] / (chair_capacity["general"] * duration), 1) if chair_capacity["general"] else 0,
         "capacity": chair_capacity["general"], "group": "physical"},
        {"label": "Sillas sala C2", "value": round(100 * chair_minutes["c2"] / (chair_capacity["c2"] * duration), 1) if chair_capacity["c2"] else 0,
         "capacity": chair_capacity["c2"], "group": "physical"},
    ])
    box_spans = spans_for("care_stage_started", "care_stage_completed",
                          lambda e: e.get("resource") == "box")
    utilization_rows.append(utilization_rows_for("Boxes", box_spans,
                                                  int(resources.get("consultation_boxes", 0)),
                                                  "physical"))
    for specialty, label in (("internal_medicine", "Médicos internistas"),
                             ("traumatology", "Médicos traumatólogos"),
                             ("surgery", "Médicos cirujanos")):
        staff_spans = spans_for({"physician_attended_c1", "care_stage_started"},
                                "care_stage_completed",
                                lambda e, s=specialty: bool(e.get("physician_id"))
                                and (e.get("specialty") == s
                                     or e.get("physician_specialty") == s))
        utilization_rows.append(utilization_rows_for(
            label, staff_spans,
            int(resources.get("physicians_by_specialty", {}).get(specialty, 0)),
            "human"))
    triage_spans = spans_for({"triage_started", "nurse_attended_c1"},
                             {"triage_completed", "care_stage_completed"},
                             lambda e: e.get("event") == "triage_started"
                             or e.get("nurse_source") == "triage_fallback")
    utilization_rows.append(utilization_rows_for(
        "Enfermeras de triage", triage_spans, int(resources.get("triage_nurses", 0)),
        "human"))
    attention_spans = spans_for({"nurse_attended_c1", "care_stage_started"},
                                "care_stage_completed",
                                lambda e: (e.get("event") == "nurse_attended_c1"
                                           and e.get("nurse_source") == "attention")
                                or (e.get("event") == "care_stage_started"
                                    and (e.get("resource") == "box"
                                         or (e.get("resource") == "resuscitation"
                                             and e.get("nurse_source") == "attention"))))
    nursing_procedure_spans = spans_for("treatment_nurse_procedure_started",
                                        "care_stage_completed")
    utilization_rows.append(utilization_rows_for(
        "Enfermeras de atención", attention_spans + nursing_procedure_spans,
        int(resources.get("box_nurses", 0)), "human"))
    admission_spans = spans_for("admission_started", "admission_completed")
    utilization_rows.append(utilization_rows_for(
        "Admisión (un tipo)", admission_spans,
        int(resources.get("admission_desks", 0)), "human"))
    cabin_spans = spans_for("triage_started", "triage_completed",
                            lambda e: e.get("mode") == "prioria")
    utilization_rows.append(utilization_rows_for(
        "Cabinas PriorIA (total)", cabin_spans,
        int(resources.get("prioria_cabins", 0)),
        "prioria"))
    for cabin_number in range(1, int(resources.get("prioria_cabins", 0)) + 1):
        cabin_id = f"cabin_{cabin_number}"
        cabin_intervals = spans_for(
            "triage_started", "triage_completed",
            lambda event, expected=cabin_id: event.get("mode") == "prioria"
            and event.get("cabin_id") == expected,
        )
        utilization_rows.append(utilization_rows_for(
            f"Cabina PriorIA {cabin_number}", cabin_intervals, 1, "prioria"))
    return {
        "arrivals_by_hour": arrivals_by_hour,
        "category_counts": category_counts,
        "abandonment_percent": round(100 * float(summary.get("abandonment_rate", 0)), 1),
        "wait_by_stage": [
            {"label": label, "minutes": round(sum(values) / len(values), 1) if values else None,
             "n": len(values)}
            for label, values in stages.items()
        ],
        "patient_states": [{"label": label, "value": value}
                           for label, value in state_counts.items()],
        "utilization": utilization_rows,
        "period_minutes": duration,
    }

# PriorIA V4.3

PriorIA V4.3 conserva el motor de simulación de eventos discretos de V2 y la
animación Canvas servida por FastAPI. La interfaz tiene dos pestañas: **Simulación**
para reproducir la jornada y **Indicadores** para revisar sus resultados. El plano
se muestra sin grilla ni batería visual de rutas.

## Ejecutar con Docker Compose

Desde la carpeta `v4`:

```powershell
docker compose up --build
```

Abre `http://localhost:8503`. Para detener, usa `Ctrl+C` y ejecuta:

```powershell
docker compose down
```

Puedes cambiar el puerto local antes de iniciar:

```powershell
$env:PRIORIA_V4_PORT = "8504"
docker compose up --build
```

Las reevaluaciones C4/C5 preceden a las consultas iniciales C4/C5 cuando compiten
por atención, conservando la prioridad de C1–C3. Las admisionistas permanecen
estáticas en sus posiciones. Las cabinas se asignan en rotación y su utilización
se informa por cabina, además del total.

## Estados del paciente

Cada fila exportada de pacientes incluye `operational_state`, una clasificación
exclusiva al cierre de la simulación:

- `no_atendido`: todavía no completó triage ni inició una atención clínica.
- `categorizado`: completó triage, pero no inició su primera atención.
- `esperando_reevaluacion`: terminó un procedimiento de tratamiento y espera el
  llamado de reevaluación. Al iniciarse la reevaluación pasa a `atendido`.
- `atendido`: inició o completó al menos una atención clínica.

La espera de reevaluación se calcula desde `treatment_completed_waiting_reevaluation`
hasta `called_to_reevaluation`. Si queda una espera abierta al llegar al límite de
seguimiento de la corrida, se registra como tiempo censurado hasta ese límite.

## Indicadores y definiciones

- **Utilización física:** minutos de ocupación de sillas generales, sillas C2 y
  boxes, divididos por la capacidad-tiempo configurada.
- **Utilización humana:** minutos ocupados de médicos por especialidad, enfermería
  de triage, enfermería de atención y admisión, divididos por su dotación-tiempo.
  El escenario actual tiene un solo tipo de admisión.
- **Utilización PriorIA:** minutos de validación de cabinas sobre la capacidad-tiempo
  de cabinas configuradas.
- **Espera de categorización:** llegada a triage completado. C1 omite el triage
  rutinario, por lo que no entra en este promedio.
- **Espera de atención:** triage completado al primer llamado clínico. Para C1, que
  ingresa directamente a reanimación, se mide desde su llegada al llamado.
- **Espera de reevaluación:** fin del procedimiento de tratamiento al llamado para
  reevaluar.
- **Espera de hospitalización:** decisión de hospitalizar hasta el evento de
  hospitalización. Actualmente el modelo no tiene cola ni demora por camas; por
  eso el indicador puede ser cero.
- **LOS:** llegada hasta alta, hospitalización o abandono. Los pacientes que siguen
  activos al límite de seguimiento aportan tiempo censurado hasta ese corte.
- **Categorías y abandono:** se calculan sobre la cohorte que llega dentro de la
  ventana medida. Los tiempos de espera de reevaluación corresponden a quienes
  alcanzan ese estado, no a toda la cohorte.

Los casos C1 sintéticos ingresan directamente a la cola de reanimación, no usan las
salas de espera ni abandonan, reciben atención en una camilla de reanimación y luego
se hospitalizan. Su categoría está definida en el perfil sintético antes del ingreso.

La cohorte de referencia es 100 pacientes sintéticos por día. La curva horaria y las
distribuciones clínicas aún son supuestos sintéticos no calibrados con DEIS. El
calentamiento por defecto es un día; su duración no demuestra por sí sola un estado
estable.


# PriorIA V4.11

PriorIA V4.11 conserva el motor de simulación de eventos discretos de V2 y la
animación Canvas servida por FastAPI. La interfaz tiene dos pestañas: **Simulación**
para reproducir la jornada y **Indicadores** para revisar sus resultados. El plano
se muestra sin grilla ni batería visual de rutas.

## Ejecutar con Docker Compose

Desde la carpeta `v4`:

```powershell
docker compose up --build
```

Abre `http://localhost:8503`. Para detener, usa `Ctrl+C` y ejecuta:

```powershell
docker compose down
```

Puedes cambiar el puerto local antes de iniciar:

```powershell
$env:PRIORIA_V4_PORT = "8504"
docker compose up --build
```

La prioridad clínica de atención es estricta: C1, C2, C3, reevaluación, C4 y C5.
Una solicitud de menor nivel no adelanta a pacientes de mayor prioridad que sigan
esperando, aunque su especialidad esté temporalmente ocupada. Dentro de cada nivel
se conserva el orden de espera. Los C1 se asignan primero al circuito de reanimación.
Las admisionistas permanecen estáticas en sus posiciones. Las cabinas se asignan
en rotación y su utilización se informa por cabina, además del total.

Antes de admisión se registra una decisión de ruta. Los pacientes que eligen PriorIA
van directamente a la cola de cabina y no ocupan admisionista; quienes siguen la ruta
tradicional pasan por admisión y luego esperan triage humano. C1 continúa directamente
a reanimación. El tiempo llegada–categorización incluye admisión solo en la ruta tradicional.

## Estados del paciente

Cada fila exportada de pacientes incluye `operational_state`, una clasificación
exclusiva al cierre de la simulación:

- `no_atendido`: todavía no completó triage ni inició una atención clínica.
- `categorizado`: completó triage, pero no inició su primera atención.
- `esperando_reevaluacion`: terminó un procedimiento de tratamiento y espera el
  llamado de reevaluación. Al iniciarse la reevaluación pasa a `atendido`.
- `atendido`: inició o completó al menos una atención clínica.

La espera de reevaluación se calcula desde `treatment_completed_waiting_reevaluation`
hasta `called_to_reevaluation`. Si queda una espera abierta al llegar al límite de
seguimiento de la corrida, se registra como tiempo censurado hasta ese límite.

## Indicadores y definiciones

- **Utilización física:** minutos de ocupación de sillas generales, sillas C2 y
  boxes, divididos por la capacidad-tiempo configurada.
- **Utilización humana:** minutos ocupados de médicos por especialidad, enfermería
  de triage, enfermería de atención y admisión, divididos por su dotación-tiempo.
  El escenario actual tiene un solo tipo de admisión.
- **Utilización PriorIA:** minutos de validación de cabinas sobre la capacidad-tiempo
  de cabinas configuradas.
- **Llegada a categorización completa:** llegada hasta terminar el triage. En la
  ruta tradicional incluye admisión, cola y duración del servicio; PriorIA omite
  admisión y pasa desde la decisión de ruta a la cola de cabina. C1 omite el triage rutinario.
- **Llegada a inicio de triage:** llegada hasta el inicio del servicio; incluye
  admisión solo en la ruta tradicional.
- **Duración de triage:** desde el inicio hasta la finalización del servicio.
- **Llegada a PriorIA/triage humano completo:** desglosa el tiempo total según la
  ruta de categorización seleccionada.
- **Espera de atención:** triage completado al primer llamado clínico. Para C1, que
  ingresa directamente a reanimación, se mide desde su llegada al llamado.
- **Espera de reevaluación:** fin del procedimiento de tratamiento al llamado para
  reevaluar.
- **Espera de hospitalización:** demora aleatoria de 120 a 240 minutos entre la
  decisión de hospitalizar y la asignación de cama. Es un supuesto de duración;
  no representa una cola con capacidad finita ni competencia entre pacientes. Esta espera se registra fuera del plano y no prolonga la ocupación de boxes o camillas de urgencia.
- **Evolución posterior a la atención:** observación y efecto de indicaciones por
  un tiempo aleatorio de 30 a 120 minutos.
- **LOS:** llegada hasta alta, hospitalización o abandono. Los pacientes que siguen
  activos al límite de seguimiento aportan tiempo censurado hasta ese corte.
- **Categorías y abandono:** se calculan sobre la cohorte que llega dentro de la
  ventana medida. Los tiempos de espera de reevaluación corresponden a quienes
  alcanzan ese estado, no a toda la cohorte.

Los casos C1 sintéticos ingresan directamente a la cola de reanimación, no usan las
salas de espera ni abandonan, reciben atención en una camilla de reanimación y luego
se hospitalizan. Su categoría está definida en el perfil sintético antes del ingreso.

La cohorte de referencia es 100 pacientes sintéticos por día. La curva horaria y las
distribuciones clínicas aún son supuestos sintéticos no calibrados con DEIS. El
calentamiento por defecto es un día; su duración no demuestra por sí sola un estado
estable.


## Distribuciones iniciales del escenario

El escenario base usa 5% de llegadas por Carabineros (policía) y 5% de pacientes C1. Los medios de llegada se distribuyen en 90% por sus propios medios, 5% ambulancia y 5% Carabineros. La distribución de categorías es C1 5%, C2 12%, C3 35%, C4 32% y C5 16%. Estos valores son parámetros sintéticos editables del escenario.


## Lectura de gráficos

Las barras usan etiquetas multilínea y desplazamiento horizontal cuando no caben en la tarjeta. Las categorías de gravedad mantienen los colores del simulador: C1 rojo, C2 naranja, C3 amarillo, C4 azul y C5 verde.


El panel mantiene el histograma con sus 24 barras horarias visibles y muestra cuántas personas iniciaron triage en una cabina PriorIA, junto con su porcentaje de la cohorte.


La pestaña de indicadores conserva una cuadrícula compacta de dos columnas. En categorías, utilización física, utilización humana y PriorIA se aumenta el grosor de las barras y el tamaño de las etiquetas dentro de tarjetas compactas.
